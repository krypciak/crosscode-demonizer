/**
 * The base class for all mods that are loaded using the plugin system.
 * @deprecated
 */
export class Plugin {
	preload() {}
	postload() {}
	prestart() {}
	main() {}
}
