[![Discord Server](https://img.shields.io/discord/382339402338402315.svg?label=Discord%20Server)](https://discord.gg/3Xw69VjXfW)
# CCLoader
A Modloader for CrossCode written in javascript.

## Installation 

1. Download the repository by left clicking on the `Clone or download` and left click on `Download Zip`.
2. Unzip the zip file.
3. Copy the contents of the folder into your CrossCode installation folder.
